
import matplotlib
matplotlib.use("Agg")

from flask import Flask, render_template, request, redirect, url_for, send_file, flash
import pandas as pd
import sqlite3
import os
from datetime import datetime
from io import BytesIO
import matplotlib.pyplot as plt

app = Flask(__name__)
app.secret_key = 'secret'
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
DB_PATH = "finance.db"

def get_db():
    return sqlite3.connect(DB_PATH)

@app.route("/")
def dashboard():
    conn = get_db()
    meta = pd.read_sql_query("SELECT * FROM meta", conn)
    sku_stats = pd.read_sql_query("SELECT normalized_sku, COUNT(*) as alias_count FROM sku_map GROUP BY normalized_sku", conn)
    conn.close()
    return render_template("dashboard.html", meta=meta, sku_stats=sku_stats)

@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        shopify = request.files.get("shopify")
        qbo = request.files.get("qbo")
        conn = get_db()

        if shopify:
            df = pd.read_csv(shopify)
            cleaned = df[["Created at", "Lineitem sku", "Lineitem name", "Lineitem quantity", "Lineitem price", "Total"]].copy()
            cleaned.columns = ["created_at", "sku", "description", "quantity", "price", "total"]
            cleaned.to_sql("shopify", conn, if_exists="replace", index=False)
            conn.execute("REPLACE INTO meta (source, last_updated) VALUES (?, ?)", ("shopify", datetime.now().isoformat()))

        if qbo:
            df = pd.read_excel(qbo, skiprows=4)
            df.columns = [
                "deleted_code", "transaction_date", "transaction_type", "transaction_number",
                "customer_name", "line_description", "quantity", "sales_price", "amount", "balance",
                "product_service"
            ]
            df = df[df["transaction_date"].notna()]
            cleaned = df[["transaction_date", "product_service", "line_description", "quantity", "sales_price", "amount"]].copy()
            cleaned.columns = ["created_at", "sku", "description", "quantity", "price", "total"]
            cleaned.to_sql("qbo", conn, if_exists="replace", index=False)
            conn.execute("REPLACE INTO meta (source, last_updated) VALUES (?, ?)", ("qbo", datetime.now().isoformat()))

        conn.commit()
        conn.close()
        flash("Files uploaded and data updated.")
        return redirect(url_for("dashboard"))
    return render_template("upload.html")

@app.route("/sku-map", methods=["GET", "POST"])
def sku_map():
    conn = get_db()
    if request.method == "POST":
        alias = request.form.get("alias")
        normalized = request.form.get("normalized_sku")
        if alias and normalized:
            conn.execute("REPLACE INTO sku_map (alias, normalized_sku) VALUES (?, ?)", (alias, normalized))
            conn.commit()
            flash(f"Alias '{alias}' mapped to '{normalized}'.")
    sku_map = pd.read_sql_query("SELECT * FROM sku_map ORDER BY normalized_sku", conn)
    conn.close()
    return render_template("sku_map.html", sku_map=sku_map)

@app.route("/monthly-report")
def monthly_report():
    year = request.args.get("year", default=datetime.now().year, type=int)
    conn = get_db()
    shopify = pd.read_sql_query("SELECT created_at, total FROM shopify", conn)
    qbo = pd.read_sql_query("SELECT created_at, total FROM qbo", conn)
    conn.close()

    shopify["created_at"] = pd.to_datetime(shopify["created_at"], errors='coerce')
    qbo["created_at"] = pd.to_datetime(qbo["created_at"], errors='coerce')
    all_data = pd.concat([shopify, qbo])
    all_data["created_at"] = pd.to_datetime(all_data["created_at"], errors="coerce")
    all_data = all_data.dropna(subset=["created_at"])

    all_data["year"] = all_data["created_at"].dt.year
    all_data["month"] = all_data["created_at"].dt.strftime("%b")
    all_data["month_num"] = all_data["created_at"].dt.month

    summary = all_data.groupby(["year", "month", "month_num"]).agg({"total": "sum"}).reset_index()
    cutoff_month = datetime.now().month

    # Ensure created_at column exists and is datetime
    if "created_at" not in all_data.columns:
        for col in all_data.columns:
            if "date" in col.lower() or "created" in col.lower():
                all_data["created_at"] = pd.to_datetime(all_data[col], errors="coerce")
                break
    else:
        all_data["created_at"] = pd.to_datetime(all_data["created_at"], errors="coerce")

    all_data.dropna(subset=["created_at"], inplace=True)

    print("Loaded records by month:")
    print(all_data["created_at"].dt.to_period("M").value_counts().sort_index())

    all_data["normalized_sku"] = all_data["sku"].str.lower().str.strip() if "sku" in all_data.columns else ""
    machine_data = {}
    chem_data = {}
    for row in all_data.itertuples():
        sku = row.normalized_sku
        m = row.month
        amt = row.total

        if "detergent" in sku or "filter" in sku:
            chem_data.setdefault(sku, {}).setdefault(m, 0)
            chem_data[sku][m] += amt
            chem_data[sku]["total"] = chem_data[sku].get("total", 0) + amt
        else:
            machine_data.setdefault(sku, {}).setdefault(m, 0)
            machine_data[sku][m] += amt
            machine_data[sku]["total"] = machine_data[sku].get("total", 0) + amt

    this_year = summary[summary["year"] == year].set_index("month")
    last_year = summary[summary["year"] == year - 1].set_index("month")

    months_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    rows = []
    for i, month in enumerate(months_order, start=1):
        current = this_year["total"].get(month, 0)
        previous = last_year["total"].get(month, 0)
        if previous > 0:
            pct = f"{((current - previous)/previous)*100:.1f}%"
        elif current > 0:
            pct = "∞"
        else:
            pct = "-"
        rows.append((month, current, previous, pct, i))

    years = sorted(summary["year"].unique(), reverse=True)
    return render_template("report.html", rows=rows, selected_year=year, years=years, months=months_order[:cutoff_month], machine_data=machine_data, chem_data=chem_data)

@app.route("/report-chart")
def report_chart():
    year = request.args.get("year", default=datetime.now().year, type=int)
    conn = get_db()
    shopify = pd.read_sql_query("SELECT created_at, total FROM shopify", conn)
    qbo = pd.read_sql_query("SELECT created_at, total FROM qbo", conn)
    conn.close()

    shopify["created_at"] = pd.to_datetime(shopify["created_at"], errors='coerce')
    qbo["created_at"] = pd.to_datetime(qbo["created_at"], errors='coerce')
    all_data = pd.concat([shopify, qbo])
    all_data["created_at"] = pd.to_datetime(all_data["created_at"], errors="coerce")
    all_data = all_data.dropna(subset=["created_at"])
    all_data["year"] = all_data["created_at"].dt.year
    all_data["month"] = all_data["created_at"].dt.strftime("%b")

    summary = all_data.groupby(["year", "month"]).agg({"total": "sum"}).reset_index()
    this_year = summary[summary["year"] == year].set_index("month")
    last_year = summary[summary["year"] == year - 1].set_index("month")

    months_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    y1 = [this_year["total"].get(m, 0) for m in months_order]
    y2 = [last_year["total"].get(m, 0) for m in months_order]

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(months_order, y1, label=f"{year}", marker="o")
    ax.plot(months_order, y2, label=f"{year - 1}", linestyle="--", marker="x")
    ax.set_title("Monthly Sales Comparison")
    ax.set_ylabel("Total Sales ($)")
    ax.legend()
    ax.grid(True)

    output = BytesIO()
    fig.tight_layout()
    plt.savefig(output, format='png')
    plt.close(fig)
    output.seek(0)
    return send_file(output, mimetype='image/png')

if __name__ == "__main__":
    app.run(debug=True)

@app.route("/debug")
def debug_summary():
    conn = sqlite3.connect(DB_FILE)
    df = pd.read_sql_query("SELECT * FROM transactions", conn)
    conn.close()

    if "created_at" not in df.columns:
        for col in df.columns:
            if "date" in col.lower() or "created" in col.lower():
                df["created_at"] = pd.to_datetime(df[col], errors="coerce")
                break
    else:
        df["created_at"] = pd.to_datetime(df["created_at"], errors="coerce")

    df["total"] = pd.to_numeric(df["total"], errors="coerce").fillna(0)
    df.dropna(subset=["created_at"], inplace=True)

    df["month"] = df["created_at"].dt.strftime("%Y-%m")
    summary = df.groupby("month").agg(count=("total", "count"), total=("total", "sum")).reset_index()
    summary = summary.sort_values("month")

    return render_template("debug.html", debug_data=summary.itertuples())
